import { Component, inject, OnInit, signal } from '@angular/core';
import { FirestoreService } from './firestore.service';
import { CommonModule, DatePipe } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Verification } from './models';

@Component({
  selector: 'app-verifications',
  standalone: true,
  imports: [CommonModule, MatIconModule, DatePipe],
  template: `
    <div class="p-4 md:p-8 max-w-6xl mx-auto">
      <div class="flex justify-between items-center mb-8">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Verifications</h1>
          <p class="text-slate-500">Real-time submissions from the verification form</p>
        </div>
        <div class="bg-indigo-50 text-indigo-700 px-4 py-2 rounded-lg flex items-center gap-2">
          <mat-icon>sync</mat-icon>
          <span class="font-medium">Live Updates</span>
        </div>
      </div>

      <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse">
            <thead>
              <tr class="bg-slate-50 border-b border-slate-200 text-xs uppercase text-slate-500 font-semibold">
                <th class="px-6 py-4">Timestamp</th>
                <th class="px-6 py-4">Name</th>
                <th class="px-6 py-4">Email</th>
                <th class="px-6 py-4">Phone</th>
                <th class="px-6 py-4">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (item of verifications(); track item.id) {
                <tr class="hover:bg-slate-50 transition-colors">
                  <td class="px-6 py-4 text-slate-500 text-sm whitespace-nowrap">
                    {{ (item.timestamp ? item.timestamp.seconds * 1000 : 0) | date:'medium' }}
                  </td>
                  <td class="px-6 py-4 font-medium text-slate-900">
                    {{ item.name }}
                  </td>
                  <td class="px-6 py-4 text-slate-600">
                    {{ item.email }}
                  </td>
                  <td class="px-6 py-4 text-slate-600 font-mono text-sm">
                    {{ item.phone }}
                  </td>
                  <td class="px-6 py-4">
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800 border border-emerald-200">
                      <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      Verified
                    </span>
                  </td>
                </tr>
              } @empty {
                <tr>
                  <td colspan="5" class="px-6 py-12 text-center text-slate-400">
                    <div class="flex flex-col items-center gap-3">
                      <mat-icon class="text-4xl text-slate-300">inbox</mat-icon>
                      <p>No verifications received yet.</p>
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class VerificationsComponent implements OnInit {
  firestore = inject(FirestoreService);
  verifications = signal<Verification[]>([]);

  ngOnInit() {
    this.firestore.getVerifications((data) => {
      // Sort by timestamp descending
      const sorted = (data as Verification[]).sort((a, b) => {
        const timeA = a.timestamp?.seconds || 0;
        const timeB = b.timestamp?.seconds || 0;
        return timeB - timeA;
      });
      this.verifications.set(sorted);
    });
  }
}
