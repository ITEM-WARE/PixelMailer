import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';

const firebaseConfig = {
  "projectId": "ai-studio-applet-webapp-9d383",
  "appId": "1:63609359078:web:4dbf518d7ee9f808cfc927",
  "apiKey": "AIzaSyCTDXREIs06AWzTcBQj3spidYggHhXCbbA",
  "authDomain": "ai-studio-applet-webapp-9d383.firebaseapp.com",
  "firestoreDatabaseId": "ai-studio-bd25bfe0-65da-412f-8d7d-34fb27b76d24",
  "storageBucket": "ai-studio-applet-webapp-9d383.firebasestorage.app",
  "messagingSenderId": "63609359078",
  "measurementId": ""
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

async function test() {
  const snapshot = await getDocs(collection(db, 'verifications'));
  console.log("Docs found:", snapshot.docs.length);
  snapshot.docs.forEach(doc => {
    console.log(doc.id, doc.data());
  });
}

test().catch(console.error);
