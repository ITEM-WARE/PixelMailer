import { Routes } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
import { LoginComponent } from './login.component';
import { DashboardComponent } from './dashboard.component';
import { SmtpComponent } from './smtp.component';
import { TemplatesComponent } from './templates.component';
import { VerificationsComponent } from './verifications.component';

const authGuard = () => {
  const auth = inject(AuthService);
  const router = inject(Router);
  
  if (auth.user()) {
    return true;
  }
  
  return router.parseUrl('/login');
};

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [authGuard] },
  { path: 'smtp', component: SmtpComponent, canActivate: [authGuard] },
  { path: 'templates', component: TemplatesComponent, canActivate: [authGuard] },
  { path: 'verifications', component: VerificationsComponent, canActivate: [authGuard] },
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];
