export interface User {
  email: string;
  role: 'admin';
}

export interface SmtpServer {
  id: string;
  host: string;
  port: number;
  authUser: string;
  authPass: string;
  isActive: boolean;
  rotationOrder: number;
}

export interface Template {
  id: string;
  name: string;
  subject: string;
  htmlBody: string;
  type: 'warning' | 'phishing';
}

export interface RecipientHistory {
  templateId: string;
  sentAt: string;
  smtpUsed: string;
}

export interface Recipient {
  id: string;
  email: string;
  name: string;
  status: 'pending' | 'warning_sent' | 'phishing_sent';
  history: RecipientHistory[];
}

export interface Verification {
  id: string;
  name: string;
  email: string;
  phone: string;
  timestamp: { seconds: number, nanoseconds: number };
}
