const url = "https://firestore.googleapis.com/v1/projects/ai-studio-applet-webapp-9d383/databases/ai-studio-bd25bfe0-65da-412f-8d7d-34fb27b76d24/documents/verifications?key=AIzaSyCTDXREIs06AWzTcBQj3spidYggHhXCbbA";

const payload = {
    fields: {
        name: { stringValue: "Test User" },
        email: { stringValue: "test@example.com" },
        phone: { stringValue: "1234567890" },
        timestamp: { timestampValue: new Date().toISOString() }
    }
};

fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
})
.then(r => r.json())
.then(data => console.log(JSON.stringify(data, null, 2)))
.catch(console.error);
